# sample-spring-app
This is just a sample for the beginners as an introduction to the web application development using spring boot.
