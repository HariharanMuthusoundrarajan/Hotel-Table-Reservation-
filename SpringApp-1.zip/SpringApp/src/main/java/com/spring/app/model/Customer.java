package com.spring.app.model;

import java.io.Serializable;

/**
 *
 * @author RP
 */
/**
 * This is a model of the customer object with its attributes.
 */
public class Customer implements Serializable {

// Create private fields for customer class

// Create an empty constructor for customer class

// Create a constructor for customer class

// Create accessor methods (i.e., getter and setter methods) for private field
    
}
