package com.spring.app.model;

/**
 *
 * @author RP
 */
/**
 * This is a model of the booking object with its attributes.
 */
public class Booking {

// Create private fields for booking class

// Create an empty constructor for booking class

// Create a constructor for booking class

// Create accessor methods (i.e., getter and setter methods) for private field

}
