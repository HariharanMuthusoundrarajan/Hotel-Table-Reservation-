/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.spring.app;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.spring.app.model.Admin;
import com.spring.app.model.Booking;
import com.spring.app.model.Customer;
import com.spring.app.model.Hotel;
import java.util.List;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

/**
 *
 * @author RP
 */
@Service
public class SampleBE {

    private static SampleBE SampleBE = null;
    public static final int SUCCESS = 1;
    public static final int FAILURE = 0;
    @Autowired
    JdbcTemplate jdbc;

    private SampleBE() {
        SampleBE = this;
    }

    public static SampleBE getInstance() {
        if (SampleBE == null) {
            SampleBE = new SampleBE();
        }
        return SampleBE;
    }

    public int adminLogin(Admin admin) {

        /**
         * This method is used to login as admin.
         *
         * @param admin This is the parameter to adminLogin method.
         * @return int This returns count of adminLogin SUCCESS or FAILURE.
         */
// Write the adminLogin() code below
    }

    public List<Booking> viewBooking() {

        /**
         * This method is used to view bookings.
         *
         * @param args Unused.
         * @return list This returns list of bookings.
         */
// Write the viewBooking() code below
    }

    public int clearBookings() {

        /**
         * This method is used to clear bookings.
         *
         * @param args Unused.
         * @return int This returns status of clearBookings SUCCESS or FAILURE.
         */
// Write the clearBookings() code below
    }

    public JSONObject customerLogin(Customer customer) {

        /**
         * This method is used to login as customer.
         *
         * @param customer This is the parameter to customerLogin method.
         * @return JSON This returns customerID as JSON.
         */
// Write the customerLogin() code below  
    }

    public int customerRegister(Customer customer) {

        /**
         * This method is used to register as customer.
         *
         * @param customer This is the parameter to customerRegister method.
         * @return int This returns status of customerRegister SUCCESS or
         * FAILURE.
         */
// Write the customerRegister() code below
    }

    public int createBooking(Booking booking) {

        /**
         * This method is used to create booking.
         *
         * @param booking This is the parameter to createBooking method.
         * @return int This returns status of createBooking SUCCESS or FAILURE.
         */
// Write the following code below
    }

    public int checkAvailability(int threshold) {

        /**
         * This method is used to check booking availability.
         *
         * @param threshold This is the parameter to checkAvailability method.
         * @return int This returns status of checkAvailability SUCCESS or
         * FAILURE.
         */
// Write the checkAvailability() code below
    }

    public int checkUser(String email) {

        /**
         * This method is used to check whether customer already exists or not.
         *
         * @param email This is the parameter to checkUser method.
         * @return int This returns count of checkUser SUCCESS or FAILURE.
         */
// Write the checkUser() code below
    }

}
